![Feri](https://i.imgur.com/UKcwuI5.jpg)


# About me
- **Nama**  : `Feri`
- **Status**: `Pelajar`
- **Umur**  : `17`
- **Fav**   : `korea, japan`
- **Asal**  : `Jawa timur/Trenggalek`
- **Zodiak**: `Pisces`


### Skills
- Tidur (100%)
- Makan (100%)
- Sange (100%)
- Belajar kode (-1%)


### Stats:
<p align="center"><a href="https://github.com/feriexp"><img src="https://github-readme-stats.vercel.app/api?username=feriexp&show_icons=true&theme=radical"></a></p>
<p align="center"><a href="https://github.com/feriexp"><img src="https://github-readme-stats.vercel.app/api/top-langs/?username=feriexp&theme=radical&layout=compact"></a></p> 


<p>
    <img src="https://img.shields.io/badge/OS-Linux-blue?&logo=Linux" />
    <img src="https://img.shields.io/badge/OS-Windows-blue?&logo=Windows" />
    <img src="https://img.shields.io/badge/IDE-Xcode-blue?&logo=xcode" />
    <img src="https://img.shields.io/badge/Text%20Editor-Visual%20Studio%20Code-blue?&logo=visual%20studio%20code&logoColor=blue" />
    <img src="https://img.shields.io/badge/Sublime%20Text-gray?&logo=Sublime-Text" />
</p>

### Let's connect!
<p>
    <a href="https://t.me/xlficks" target="blank"><img src="https://img.shields.io/badge/@xflicks-30302f?style=flat&logo=telegram" /></a>
    <a href="https://instagram.com/ferikunn" target="blank"><img src="https://img.shields.io/badge/@ferikunn-30302f?style=flat&logo=instagram" /></a>
</p>
<details>
    <summary>&#127942 <b>GitHub Awards</b></summary><br/>

![Github Trophy](https://github-profile-trophy.vercel.app/?username=phaticusthiccy)

</details>

<details>
    <summary>&#127942 <b>GitHub Activity</b></summary><br/>

![Metrics](https://metrics.lecoq.io/feriexp?template=classic&repositories.forks=true&languages=1&languages.colors=github&languages.threshold=0%25&config.timezone=Asia%2FJakarta)


</details>
